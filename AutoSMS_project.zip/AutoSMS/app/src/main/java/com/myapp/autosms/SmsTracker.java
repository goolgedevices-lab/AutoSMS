package com.myapp.autosms;

import android.content.Context;
import android.content.SharedPreferences;

public class SmsTracker {

    private static final String PREFS = "SmsSentLog";
    private final SharedPreferences prefs;

    public SmsTracker(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // Raqam avval SMS oldimi?
    public boolean isSmsSentBefore(String number) {
        return prefs.contains(normalize(number));
    }

    // Raqamni yuborilganlar ro'yxatiga qo'shish
    public void markSmsSent(String number) {
        prefs.edit()
             .putLong(normalize(number), System.currentTimeMillis())
             .apply();
    }

    // Barcha ma'lumotlarni tozalash
    public void clearAll() {
        prefs.edit().clear().apply();
    }

    // Raqamni standart formatga keltirish
    // +998901234567 = 998901234567 = 0901234567 — barchasi bir xil
    private String normalize(String number) {
        if (number == null) return "unknown";
        String clean = number.replaceAll("[^0-9+]", "");

        if (clean.startsWith("+")) clean = clean.substring(1);
        if (clean.startsWith("998") && clean.length() == 12) return clean;
        if (clean.startsWith("0")   && clean.length() == 9)
            return "998" + clean.substring(1);

        return clean; // boshqa davlatlar uchun ham ishlaydi
    }
}