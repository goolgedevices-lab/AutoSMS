package com.myapp.autosms;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private static final int PERM_REQUEST = 100;
    private Switch switchEnable;
    private EditText etMessage;
    private Button btnSave;
    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        switchEnable = findViewById(R.id.switchEnable);
        etMessage    = findViewById(R.id.etMessage);
        btnSave      = findViewById(R.id.btnSave);
        tvStatus     = findViewById(R.id.tvStatus);

        SharedPreferences prefs = getSharedPreferences("AutoSMS", MODE_PRIVATE);

        // Saqlangan xabarni yuklash
        etMessage.setText(prefs.getString("sms_message",
            "Salom! Hozir qo'ng'irog'ingizni qabul qila olmadim. " +
            "Imkon bo'lsa Telegramdan yozing. Rahmat!"));

        // Holat
        boolean isEnabled = prefs.getBoolean("is_enabled", false);
        switchEnable.setChecked(isEnabled);
        updateStatus(isEnabled);

        // Yoqish/o'chirish
        switchEnable.setOnCheckedChangeListener((btn, checked) -> {
            prefs.edit().putBoolean("is_enabled", checked).apply();
            updateStatus(checked);

            if (checked) {
                requestPermissionsIfNeeded();
                startMonitorService();
            } else {
                stopService(new Intent(this, CallMonitorService.class));
            }
        });

        // Xabarni saqlash
        btnSave.setOnClickListener(v -> {
            String msg = etMessage.getText().toString().trim();
            if (msg.isEmpty()) {
                Toast.makeText(this, "Xabar bo'sh bo'lmasin!", Toast.LENGTH_SHORT).show();
                return;
            }
            prefs.edit().putString("sms_message", msg).apply();
            Toast.makeText(this, "Saqlandi ✓", Toast.LENGTH_SHORT).show();
        });
    }

    private void updateStatus(boolean enabled) {
        tvStatus.setText(enabled ? "✅ Faol — SMS avtomatik yuboriladi"
                                 : "⛔ O'chirilgan");
    }

    private void startMonitorService() {
        Intent intent = new Intent(this, CallMonitorService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
    }

    private void requestPermissionsIfNeeded() {
        java.util.ArrayList<String> permList = new java.util.ArrayList<>();
        permList.add(Manifest.permission.READ_PHONE_STATE);
        permList.add(Manifest.permission.READ_CALL_LOG);
        permList.add(Manifest.permission.SEND_SMS);
        if (Build.VERSION.SDK_INT >= 33) {
            permList.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        String[] perms = permList.toArray(new String[0]);
        boolean allGranted = true;
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p)
                    != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }
        if (!allGranted) {
            ActivityCompat.requestPermissions(this, perms, PERM_REQUEST);
        }
    }
}