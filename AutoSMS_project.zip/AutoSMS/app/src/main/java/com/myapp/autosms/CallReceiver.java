package com.myapp.autosms;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CallLog;
import android.telephony.TelephonyManager;
import android.util.Log;

public class CallReceiver extends BroadcastReceiver {

    private static final String TAG = "CallReceiver";
    private static String sLastState = TelephonyManager.EXTRA_STATE_IDLE;
    private static String sIncomingNumber = "";
    private static boolean sWasRinging = false;

    @Override
    public void onReceive(Context context, Intent intent) {

        // Ilova yoqilganmi tekshirish
        SharedPreferences prefs = context.getSharedPreferences("AutoSMS", Context.MODE_PRIVATE);
        if (!prefs.getBoolean("is_enabled", false)) return;

        String action = intent.getAction();
        if (action == null || !action.equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED)) return;

        String state  = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
        String number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);

        if (number != null && !number.isEmpty()) {
            sIncomingNumber = number;
        }

        if (state == null) return;

        switch (state) {

            case TelephonyManager.EXTRA_STATE_RINGING:
                // Qo'ng'iroq keldi
                sWasRinging = true;
                sLastState  = state;
                Log.d(TAG, "RINGING: " + sIncomingNumber);
                break;

            case TelephonyManager.EXTRA_STATE_OFFHOOK:
                // Javob berildi
                sLastState = state;
                Log.d(TAG, "OFFHOOK — javob berildi");
                break;

            case TelephonyManager.EXTRA_STATE_IDLE:
                // Qo'ng'iroq tugadi
                if (sWasRinging &&
                    !TelephonyManager.EXTRA_STATE_OFFHOOK.equals(sLastState)) {

                    // Javob berilmagan qo'ng'iroq!
                    String missedNumber = sIncomingNumber;

                    // Android 9+ da raqamni CallLog dan olish
                    if (missedNumber.isEmpty()) {
                        missedNumber = getLastMissedNumber(context);
                    }

                    if (!missedNumber.isEmpty()) {
                        handleMissedCall(context, missedNumber, prefs);
                    }
                }
                // Reset
                sWasRinging     = false;
                sIncomingNumber = "";
                sLastState      = state;
                break;
        }
    }

    private void handleMissedCall(Context context, String number, SharedPreferences prefs) {
        SmsTracker tracker = new SmsTracker(context);

        if (tracker.isSmsSentBefore(number)) {
            Log.d(TAG, "SMS avval yuborilgan, o'tkazib yuborildi: " + number);
            return;
        }

        String message = prefs.getString("sms_message",
            "Salom! Hozir qo'ng'irog'ingizni qabul qila olmadim. " +
            "Imkon bo'lsa Telegramdan yozing. Rahmat!");

        boolean sent = SmsHelper.sendSms(number, message);

        if (sent) {
            tracker.markSmsSent(number);
            Log.d(TAG, "SMS yuborildi: " + number);
        }
    }

    // Android 9+ uchun CallLog dan raqam olish
    private String getLastMissedNumber(Context context) {
        try {
            Uri uri = CallLog.Calls.CONTENT_URI;
            String[] proj = { CallLog.Calls.NUMBER, CallLog.Calls.TYPE };
            String sel  = CallLog.Calls.TYPE + " = " + CallLog.Calls.MISSED_TYPE;
            String sort = CallLog.Calls.DATE + " DESC";

            Cursor cursor = context.getContentResolver()
                .query(uri, proj, sel, null, sort);

            if (cursor != null && cursor.moveToFirst()) {
                String num = cursor.getString(
                    cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER));
                cursor.close();
                return num != null ? num : "";
            }
            if (cursor != null) cursor.close();

        } catch (Exception e) {
            Log.e(TAG, "CallLog xatosi: " + e.getMessage());
        }
        return "";
    }
}