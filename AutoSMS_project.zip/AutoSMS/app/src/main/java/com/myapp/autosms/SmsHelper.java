package com.myapp.autosms;

import android.telephony.SmsManager;
import android.util.Log;
import java.util.ArrayList;

public class SmsHelper {

    private static final String TAG = "SmsHelper";

    public static boolean sendSms(String number, String message) {
        try {
            SmsManager manager = SmsManager.getDefault();
            ArrayList<String> parts = manager.divideMessage(message);

            if (parts.size() == 1) {
                manager.sendTextMessage(number, null, message, null, null);
            } else {
                // Uzun xabar bo'laklarga bo'linadi
                manager.sendMultipartTextMessage(number, null, parts, null, null);
            }
            return true;

        } catch (Exception e) {
            Log.e(TAG, "SMS xatosi: " + e.getMessage());
            return false;
        }
    }
}