AutoSMS Android project

Build APK in Android Studio:
1. Open the AutoSMS folder in Android Studio.
2. Let Android Studio sync Gradle.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).

Build APK in terminal, if Gradle/Android SDK is installed:
gradle assembleDebug

APK output:
app/build/outputs/apk/debug/app-debug.apk

Note: this app requests phone, call log, SMS, notification, boot, and foreground service permissions. It should be installed only on a device where you have permission to monitor missed calls and send SMS.
